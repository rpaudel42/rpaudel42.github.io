Anomalous Tweet/News:

Keyword Hijacking: 	8, 6
Bogus Link: 		257, 351, 701, 793, 1137
Link Piggybacking: 	513, 627, 719, 744, 767, 832, 853, 863, 864, 866, 884, 1016, 1098, 1180, 1206