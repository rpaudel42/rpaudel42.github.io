All healthy patient (total 242)
3 patient unhealthy
Id 6, 18 -> MCI
id 38 -> Dementia