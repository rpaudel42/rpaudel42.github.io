Anomalous Tweet/News:

Keyword Hijacking: 	--
Bogus Link: 		256, 841, 1097, 1142
Link Piggybacking: 	249, 252, 270, 610, 843, 1440, 1630