All healthy patient (total 242)
3 patient unhealthy  (Cognitive impairment)

In each graph file look for //filename <ID> next to XP # <gid> to recognize graph for the cognitively impaired patient's graph

Id 6, 18 -> MCI
id 38 -> Dementia



___________
1) Graph-Layout.pdf give the general layout of the graph
2) sample.jpeg shows the sample graph for a patient doing "fill medicine dispenser" activity
3) sensor layout shows the sensor floorplan